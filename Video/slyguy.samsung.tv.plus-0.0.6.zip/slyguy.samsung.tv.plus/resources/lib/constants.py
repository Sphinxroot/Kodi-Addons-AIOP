HEADERS = {
    'user-agent': 'okhttp/4.9.0',
}

DATA_URL = 'https://i.mjh.nz/SamsungTVPlus/{region}.json.gz'
EPG_URL = 'https://i.mjh.nz/SamsungTVPlus/{region}.xml.gz'

ALL = 'all'
US = 'us'
GB = 'gb'
CA = 'ca'
IN = 'in'
DE = 'de'
ES = 'es'
IT = 'it'
KR = 'kr'
FR = 'fr'
CH = 'ch'
AT = 'at'

REGIONS = [ALL, US, GB, CA, IN, DE, ES, IT, KR, FR, CH, AT]
