plugin.video.livestream

======================
Watch streams from livestream.com inside Kodi

