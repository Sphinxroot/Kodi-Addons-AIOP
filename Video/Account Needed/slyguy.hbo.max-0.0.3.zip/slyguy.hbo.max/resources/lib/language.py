from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    DEVICE_LINK       = 30001
    DEVICE_LINK_STEPS = 30002
    DEVICE_ID         = 30003
    API_ERROR         = 30004
    GO_TO_SERIES      = 30005
    NO_VIDEO_FOUND    = 30006
    SUBTITLES         = 30007

_ = Language()