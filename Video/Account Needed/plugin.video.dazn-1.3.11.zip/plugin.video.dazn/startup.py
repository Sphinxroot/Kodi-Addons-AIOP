# -*- coding: utf-8 -*-

from __future__ import unicode_literals

import xbmcaddon

if __name__ == '__main__':
    xbmcaddon.Addon().setSetting('startup', 'true')
