# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

import wrestlingGenres
import wrestleArchives
import wrestleMatches
from resources.lib.modules.showVID import *
from resources.lib.modules.wrestlers import *
from resources.lib.modules.common import *

#from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
#from koding import Open_Settings, Play_Video, Run, Text_File
		
params = get_params()
mode = None

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.wrestlers')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))

art = 'special://home/addons/script.module.jhm/lib/resources/art/'
mediapath = 'http://j1wizard.net/media/'

path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

@route(mode='main')
def Main():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', icon, fanart)
	addDirMain('[COLOR white][B]Episodes & Kickoffs[/B][/COLOR]','url',404,mediapath+'episodes.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Archives[/B][/COLOR]','url',405,mediapath+'archive.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Matches[/B][/COLOR]','url',408,mediapath+'match.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Channels[/B][/COLOR]',BASE,700,mediapath+'wchannels.png', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling[/B][/COLOR]',BASE,70,mediapath+'wwe.png', fanart)
	addDirMain('[COLOR white][B]AEW Wrestling[/B][/COLOR]',BASE,701,mediapath+'aew.png', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling[/B][/COLOR]',BASE,72,mediapath+'roh.png', fanart)
	addDirMain('[COLOR white][B]Impact Wrestling[/B][/COLOR]',BASE,73,mediapath+'impact.png', fanart)
	addDirMain('[COLOR white][B]Indy Playlists[/B][/COLOR]','url',402,mediapath+'playlist.png', fanart)
	addDirMain('[COLOR white][B]Womens Wrestling[/B][/COLOR]',BASE,74,mediapath+'women.png', fanart)
	addDirMain('[COLOR white][B]Legends Of Wrestling[/B][/COLOR]',BASE,75,mediapath+'legends.png', fanart)
	addDirMain('[COLOR white][B]Classic ECW Wrestling[/B][/COLOR]',BASE,76,mediapath+'ecw.png', fanart)
	addDirMain('[COLOR white][B]Classic WCW Wrestling[/B][/COLOR]',BASE,77,mediapath+'wcw.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Documentary[/B][/COLOR]',BASE,78,mediapath+'wrestlersdocs.png', fanart)
	addDirMain('[COLOR white][B]Other Indie Promotions[/B][/COLOR]',BASE,79,mediapath+'indie.png', fanart)
	addDirMain('[COLOR white][B]Tables, Ladders, And Steel[/B][/COLOR]',BASE,80,mediapath+'steel.png', fanart)
	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

@route(mode='genrelist')
def genreList():

	add_link_info('[B][COLORorange]Choose Episode Genre[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]All Wrestling Shows[/B][/COLOR]',BASE,403,art+'episodes.jpg', fanart)
	addDirMain('[COLOR white][B]AEW Wrestling Shows[/B][/COLOR]',BASE,410,art+'aew.jpg', fanart)
	addDirMain('[COLOR white][B]NWA Wrestling Shows[/B][/COLOR]',BASE,411,art+'nwa.jpg', fanart)
	addDirMain('[COLOR white][B]MLW Wrestling Shows[/B][/COLOR]',BASE,412,art+'mlw.jpg', fanart)
	addDirMain('[COLOR white][B]PCW Wrestling Shows[/B][/COLOR]',BASE,413,art+'pcw.jpg', fanart)
	addDirMain('[COLOR white][B]ROW Wrestling Shows[/B][/COLOR]',BASE,414,art+'row.jpg', fanart)
	addDirMain('[COLOR white][B]WLW Wrestling Shows[/B][/COLOR]',BASE,424,art+'wlw.jpg', fanart)
	addDirMain('[COLOR white][B]CCW Wrestling Shows[/B][/COLOR]',BASE,432,art+'ccw.jpg', fanart)
	addDirMain('[COLOR white][B]HOB Wrestling Shows[/B][/COLOR]',BASE,415,art+'hob.jpg', fanart)
	addDirMain('[COLOR white][B]OWE Wrestling Shows[/B][/COLOR]',BASE,428,art+'owe.jpg', fanart)
	addDirMain('[COLOR white][B]USACW Wrestling Shows[/B][/COLOR]',BASE,419,art+'usacw.jpg', fanart)
	addDirMain('[COLOR white][B]Smash Wrestling Shows[/B][/COLOR]',BASE,422,art+'smash.jpg', fanart)
	addDirMain('[COLOR white][B]Championship Wrestling[/B][/COLOR]',BASE,418,art+'champ.jpg', fanart)
	addDirMain('[COLOR white][B]Catalyst Wrestling Shows[/B][/COLOR]',BASE,429,art+'catalyst.jpg', fanart)
	addDirMain('[COLOR white][B]Respect Womens Wrestling[/B][/COLOR]',BASE,427,art+'respect.jpg', fanart)
	addDirMain('[COLOR white][B]PWA Ohio Wrestling[/B][/COLOR]',BASE,430,art+'pwa.jpg', fanart)
	addDirMain('[COLOR white][B]Ohio Valley Wrestling[/B][/COLOR]',BASE,426,art+'ovw.jpg', fanart)
	addDirMain('[COLOR white][B]Misc. Wrestling Shows[/B][/COLOR]',BASE,431,art+'misc.jpg', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling Kickoffs[/B][/COLOR]',BASE,416,art+'wwe6.jpg', fanart)
	addDirMain('[COLOR white][B]Britannia Wrestling[/B][/COLOR]',BASE,423,art+'brit.jpg', fanart)
	addDirMain('[COLOR white][B]FWA Wrestling Shows[/B][/COLOR]',BASE,421,art+'fwa.jpg', fanart)
	addDirMain('[COLOR white][B]PWL Wrestling Shows[/B][/COLOR]',BASE,420,art+'pwl.jpg', fanart)
	addDirMain('[COLOR white][B]House of Glory Shows[/B][/COLOR]',BASE,425,art+'hog.jpg', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling Preshows[/B][/COLOR]',BASE,417,art+'roh.jpg', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

@route(mode='archivelist')
def archiveList():

	add_link_info('[B][COLORorange]Choose Archive Genre[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]All Wrestling Events[/B][/COLOR]',BASE,406,art+'archive.jpg', fanart)
	addDirMain('[COLOR white][B]WWA Wrestling Events[/B][/COLOR]',BASE,510,art+'wwa.jpg', fanart)
	addDirMain('[COLOR white][B]MLW Wrestling Events[/B][/COLOR]',BASE,512,art+'mlw.jpg', fanart)
	addDirMain('[COLOR white][B]NWA Wrestling Events[/B][/COLOR]',BASE,511,art+'nwa.jpg', fanart)
	addDirMain('[COLOR white][B]Womens Wrestling Events[/B][/COLOR]',BASE,535,art+'wow.jpg', fanart)
	addDirMain('[COLOR white][B]IPW Wrestling Events[/B][/COLOR]',BASE,513,art+'ipw.jpg', fanart)
	addDirMain('[COLOR white][B]ROW Wrestling Events[/B][/COLOR]',BASE,514,art+'row.jpg', fanart)
	addDirMain('[COLOR white][B]AAW Wrestling Events[/B][/COLOR]',BASE,533,art+'aaw.jpg', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling Events[/B][/COLOR]',BASE,517,art+'roh.jpg', fanart)
	addDirMain('[COLOR white][B]EWF Wrestling Events[/B][/COLOR]',BASE,519,art+'ewf.jpg', fanart)
	addDirMain('[COLOR white][B]Rise Underground Events[/B][/COLOR]',BASE,527,art+'rise.jpg', fanart)
	addDirMain('[COLOR white][B]Smash Wrestling Events[/B][/COLOR]',BASE,522,art+'smash.jpg', fanart)
	addDirMain('[COLOR white][B]Defiant Wrestling Events[/B][/COLOR]',BASE,534,art+'defiant.jpg', fanart)
	addDirMain('[COLOR white][B]Championship Wrestling[/B][/COLOR]',BASE,518,art+'champ.jpg', fanart)
	addDirMain('[COLOR white][B]Misc. Wrestling Events[/B][/COLOR]',BASE,531,art+'misc.jpg', fanart)
	addDirMain('[COLOR white][B]Progress Wrestling Events[/B][/COLOR]',BASE,516,art+'progress.jpg', fanart)
	addDirMain('[COLOR white][B]Britannia Wrestling[/B][/COLOR]',BASE,523,art+'brit.jpg', fanart)
	addDirMain('[COLOR white][B]BWF Wrestling Events[/B][/COLOR]',BASE,537,art+'bwf.jpg', fanart)
	addDirMain('[COLOR white][B]FWA Wrestling Events[/B][/COLOR]',BASE,521,art+'fwa.jpg', fanart)
	addDirMain('[COLOR white][B]PWL Wrestling Events[/B][/COLOR]',BASE,520,art+'pwl.jpg', fanart)
	addDirMain('[COLOR white][B]House of Glory Events[/B][/COLOR]',BASE,525,art+'hog.jpg', fanart)
	addDirMain('[COLOR white][B]IMPACT Wrestling Events[/B][/COLOR]',BASE,528,art+'impact.jpg', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling Events[/B][/COLOR]',BASE,529,art+'wwe.jpg', fanart)
	addDirMain('[COLOR white][B]One Pro Wrestling Events[/B][/COLOR]',BASE,536,art+'1pw.jpg', fanart)
	addDirMain('[COLOR white][B]CCW Wrestling Events[/B][/COLOR]',BASE,532,art+'cascade.jpg', fanart)
	addDirMain('[COLOR white][B]HOB Wrestling Events[/B][/COLOR]',BASE,515,art+'hob.jpg', fanart)
	#addDirMain('[COLOR white][B]PWA Ohio Wrestling[/B][/COLOR]',BASE,530,art+'pwa.jpg', fanart)
	#addDirMain('[COLOR white][B]Ohio Valley Wrestling[/B][/COLOR]',BASE,526,art+'ovw.jpg', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

@route(mode='matchlist')
def matchList():

	add_link_info('[B][COLORorange]Choose Match Genre[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]All Wrestling Matches[/B][/COLOR]',BASE,407,art+'match.jpg', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling Matches[/B][/COLOR]',BASE,610,art+'wwe.jpg', fanart)
	addDirMain('[COLOR white][B]AEW Wrestling Matches[/B][/COLOR]',BASE,619,art+'aew.jpg', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling Matches[/B][/COLOR]',BASE,611,art+'roh.jpg', fanart)
	addDirMain('[COLOR white][B]IMPACT Wrestling Matches[/B][/COLOR]',BASE,612,art+'impact.jpg', fanart)
	addDirMain('[COLOR white][B]MLW Wrestling Matches[/B][/COLOR]',BASE,613,art+'mlw.jpg', fanart)
	addDirMain('[COLOR white][B]NWA Wrestling Matches[/B][/COLOR]',BASE,614,art+'nwa.jpg', fanart)
	addDirMain('[COLOR white][B]Womens Wrestling Matches[/B][/COLOR]',BASE,615,art+'wow.jpg', fanart)
	addDirMain('[COLOR white][B]ROW Wrestling Matches[/B][/COLOR]',BASE,616,art+'row.jpg', fanart)
	addDirMain('[COLOR white][B]TMN Wrestling Matches[/B][/COLOR]',BASE,618,art+'tmn.jpg', fanart)
	addDirMain('[COLOR white][B]Misc. Wrestling Matches[/B][/COLOR]',BASE,617,art+'misc.jpg', fanart)

	#addDirMain('[COLOR white][B]PWA Ohio Wrestling[/B][/COLOR]',BASE,630,art+'pwa.jpg', fanart)
	#addDirMain('[COLOR white][B]Ohio Valley Wrestling[/B][/COLOR]',BASE,626,art+'ovw.jpg', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)

#==========================================================================================================
		
params=get_params()
url=None
name=None
zmode = None
iconimage=None
mode=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        zmode = urllib.unquote_plus(params["zmode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        zmode=int(params["zmode"])
except:
        pass
print "zmode: "+str(zmode)
print "URL: "+str(url)
print "Name: "+str(name)

#=========================================
		
#errorMsg="%s" % (zmode)
#xbmcgui.Dialog().ok("zmode", errorMsg)
 
#=============WRESTLERS===================

if zmode == 70:
	WWE()
		
elif zmode == 71:
	NXT()		
		
elif zmode == 72:
	ROH()

elif zmode == 73:
	Impact()
	
elif zmode == 74:
	Womens()

elif zmode == 75:
	Legends()

elif zmode == 76:
	ECW()

elif zmode == 77:
	WCW()
	
elif zmode == 78:
	Wrestlers_Docs()

elif zmode == 79:
	Indie()

elif zmode == 80:
	Tables()

elif zmode == 700:
	W_channels()

elif zmode == 701:
	AEW()

#=========================================
		
elif zmode == 402:
	from resources.lib.modules.showsPL import *

elif zmode == 403:
    wrestlingGenres.GenreListing.Genres("All")
	
elif zmode == 404:
    genreList()
	
elif zmode == 405:
    archiveList()

elif zmode == 406:
    wrestleArchives.archiveListing.Genres("All")

elif zmode == 407:
    wrestleMatches.matchListing.Genres("All")
	
elif zmode == 408:
    matchList()

#=========================================

elif zmode == 410:
    wrestlingGenres.GenreListing.Genres("aew")

elif zmode == 411:
    wrestlingGenres.GenreListing.Genres("nwa")

elif zmode == 412:
    wrestlingGenres.GenreListing.Genres("mlw")

elif zmode == 413:
    wrestlingGenres.GenreListing.Genres("pcw")

elif zmode == 414:
    wrestlingGenres.GenreListing.Genres("row")

elif zmode == 415:
    wrestlingGenres.GenreListing.Genres("hob")

elif zmode == 416:
    wrestlingGenres.GenreListing.Genres("wwe")

elif zmode == 417:
    wrestlingGenres.GenreListing.Genres("roh")

elif zmode == 418:
    wrestlingGenres.GenreListing.Genres("champ")

elif zmode == 419:
    wrestlingGenres.GenreListing.Genres("usacw")

elif zmode == 420:
    wrestlingGenres.GenreListing.Genres("pwl")

elif zmode == 421:
    wrestlingGenres.GenreListing.Genres("fwa")

elif zmode == 422:
    wrestlingGenres.GenreListing.Genres("smash")

elif zmode == 423:
    wrestlingGenres.GenreListing.Genres("brit")

elif zmode == 424:
    wrestlingGenres.GenreListing.Genres("wlw")

elif zmode == 425:
    wrestlingGenres.GenreListing.Genres("hog")

elif zmode == 426:
    wrestlingGenres.GenreListing.Genres("ovw")

elif zmode == 427:
    wrestlingGenres.GenreListing.Genres("respect")

elif zmode == 428:
    wrestlingGenres.GenreListing.Genres("owe")

elif zmode == 429:
    wrestlingGenres.GenreListing.Genres("catalyst")

elif zmode == 430:
    wrestlingGenres.GenreListing.Genres("pwa")

elif zmode == 431:
    wrestlingGenres.GenreListing.Genres("misc")

elif zmode == 432:
    wrestlingGenres.GenreListing.Genres("ccw")

#=========================================

elif zmode == 510:
    wrestleArchives.archiveListing.Genres("wwa")

elif zmode == 511:
    wrestleArchives.archiveListing.Genres("nwa")

elif zmode == 512:
    wrestleArchives.archiveListing.Genres("mlw")

elif zmode == 513:
    wrestleArchives.archiveListing.Genres("ipw")

elif zmode == 514:
    wrestleArchives.archiveListing.Genres("row")

elif zmode == 515:
    wrestleArchives.archiveListing.Genres("hob")

elif zmode == 516:
    wrestleArchives.archiveListing.Genres("progress")

elif zmode == 517:
    wrestleArchives.archiveListing.Genres("roh")

elif zmode == 518:
    wrestleArchives.archiveListing.Genres("champ")

elif zmode == 519:
    wrestleArchives.archiveListing.Genres("ewf")

elif zmode == 520:
    wrestleArchives.archiveListing.Genres("pwl")

elif zmode == 521:
    wrestleArchives.archiveListing.Genres("fwa")

elif zmode == 522:
    wrestleArchives.archiveListing.Genres("smash")

elif zmode == 523:
    wrestleArchives.archiveListing.Genres("brit")

elif zmode == 524:
    wrestleArchives.archiveListing.Genres("wlw")

elif zmode == 525:
    wrestleArchives.archiveListing.Genres("hog")

elif zmode == 526:
    wrestleArchives.archiveListing.Genres("ovw")

elif zmode == 527:
    wrestleArchives.archiveListing.Genres("rise")

elif zmode == 528:
    wrestleArchives.archiveListing.Genres("tna")

elif zmode == 529:
    wrestleArchives.archiveListing.Genres("wwe")

elif zmode == 530:
    wrestleArchives.archiveListing.Genres("pwa")

elif zmode == 531:
    wrestleArchives.archiveListing.Genres("misc")

elif zmode == 532:
    wrestleArchives.archiveListing.Genres("ccw")

elif zmode == 533:
    wrestleArchives.archiveListing.Genres("aaw")

elif zmode == 534:
    wrestleArchives.archiveListing.Genres("defiant")

elif zmode == 535:
    wrestleArchives.archiveListing.Genres("women")

elif zmode == 536:
    wrestleArchives.archiveListing.Genres("1pw")

elif zmode == 537:
    wrestleArchives.archiveListing.Genres("bwf")

#=========================================

elif zmode == 610:
    wrestleMatches.matchListing.Genres("wwe")

elif zmode == 611:
    wrestleMatches.matchListing.Genres("roh")

elif zmode == 612:
    wrestleMatches.matchListing.Genres("tna")

elif zmode == 613:
    wrestleMatches.matchListing.Genres("mlw")

elif zmode == 614:
    wrestleMatches.matchListing.Genres("nwa")

elif zmode == 615:
    wrestleMatches.matchListing.Genres("women")

elif zmode == 616:
    wrestleMatches.matchListing.Genres("row")

elif zmode == 617:
    wrestleMatches.matchListing.Genres("misc")

elif zmode == 618:
    wrestleMatches.matchListing.Genres("tmn")

elif zmode == 619:
    wrestleMatches.matchListing.Genres("aew")

#=========================================
		
elif zmode == 801:
		
	#errorMsg="%s" % (url)
	#xbmcgui.Dialog().ok("url", errorMsg)

	Common.getVID(url)
		
elif zmode == 802:
	from resources.lib.modules.yt_playlists import *        
	#main_list(params)
		
elif zmode == 803:
	from resources.lib.modules.yt_channels import *        
	#main_list(params)
		
elif zmode == 804:
	import resources.lib.modules.yt_video

#=========================================		

elif zmode is None and mode is None:
	print ""
	Main()
		
xbmcplugin.endOfDirectory(plugin_handle)

#----------------------------------------------------------------
# A basic OK Dialog
#@route(mode='koding_settings')
#def Koding_Settings():
#    Open_Settings()
#----------------------------------------------------------------
# A basic OK Dialog
#@route(mode='simple_dialog', args=['title','msg'])
#def Simple_Dialog(title,msg):
#    OK_Dialog(title, msg)


#xbmcplugin.endOfDirectory(int(sys.argv[1]))

#if __name__ == "__main__":
#    Run(default='main')
#    xbmcplugin.endOfDirectory(int(sys.argv[1]))