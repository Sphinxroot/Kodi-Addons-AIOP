# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

from resources.lib.modules.sportz import *
from resources.lib.modules.common import *

params = get_params()
mode = None

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.sportz')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'
path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

@route(mode='main')
def Main():

	add_link_info('[B][COLORorange]== Sportz ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Live Sports[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3573+"/", folder=True,
		icon=mediapath+"LiveSports.png", fanart=mediapath+'fanart.jpg')
	
	addDirMain('[COLOR white][B]Game Sports[/B][/COLOR]',BASE,100,mediapath+'GameSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Motor Sports[/B][/COLOR]',BASE,101,mediapath+'motorsports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Euro Sports[/B][/COLOR]',BASE,103,mediapath+'eurosports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Womens Sports[/B][/COLOR]',BASE,104,mediapath+'WomensSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Combat Sports[/B][/COLOR]',BASE,109,mediapath+'combat.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports Documentaries[/B][/COLOR]',BASE,107,mediapath+'DocsSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Wrestling[/B][/COLOR]',BASE,106,mediapath+'SportsWrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Womens Wrestling[/B][/COLOR]',BASE,105,mediapath+'WomansWrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Fishing[/B][/COLOR]',BASE,108,mediapath+'fishing.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Hunting[/B][/COLOR]',BASE,102,mediapath+'hunting.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#==========================================================================================================

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)

#==========================================================================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
zmode=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        zmode=int(params["zmode"])
except:
        pass
print "Zmode: "+str(zmode)
print "URL: "+str(url)
print "Name: "+str(name)

if zmode == 100:
	GameSports()
		
elif zmode == 101:
	Motorsports()		
		
elif zmode == 102:
	Hunting()

elif zmode == 103:
	Eurosports()
	
elif zmode == 104:
	WomensSports()

elif zmode == 105:
	WomensWrestling()

elif zmode == 106:
	SportsWrestling()

elif zmode == 107:
	Docs_sports()
	
elif zmode == 108:
	Fishing()

elif zmode == 109:
	Combat()

elif zmode is None and mode is None:
	Main()
	
else:
    Main()
		
xbmcplugin.endOfDirectory(plugin_handle)

#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()
#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

#if __name__ == "__main__":
#    Run(default='main')
#    xbmcplugin.endOfDirectory(int(sys.argv[1]))