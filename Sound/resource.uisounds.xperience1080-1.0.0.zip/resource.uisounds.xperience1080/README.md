 UI Sounds for the Kodi Xperience1080 skin.
