# resource.uisounds.refocus
UI sounds package for the [reFocus](https://github.com/jeroenpardon/skin.refocus) skin for [Kodi](http://www.kodi.tv/)
