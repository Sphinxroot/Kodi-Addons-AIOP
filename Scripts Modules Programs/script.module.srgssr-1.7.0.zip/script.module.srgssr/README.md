# SRGSSR

`script.module.srgssr` is a [Kodi](https://kodi.tv) module that implements all the functionalities needed for other Kodi plugins to play content (video and audio) from SRG SSR.

Currently, these Kodi plugins use `script.module.srgssr`:

* [plugin.video.srfplaytv](https://github.com/goggle/plugin.video.srfplaytv)
* [plugin.video.rtsplaytv](https://github.com/goggle/plugin.video.rtsplaytv)
* [plugin.video.rsiplaytv](https://github.com/goggle/plugin.video.rsiplaytv)
* [plugin.audio.srfplayradio](https://github.com/goggle/plugin.audio.srfplayradio)