
from resources.lib.tvmi import tvmMonitor

if ( __name__ == "__main__" ):
    tvmMonitor()
