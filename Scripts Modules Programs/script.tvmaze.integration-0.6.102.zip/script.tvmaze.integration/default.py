
from resources.lib.tvmi import tvmManual

if ( __name__ == "__main__" ):
    tvmManual()
