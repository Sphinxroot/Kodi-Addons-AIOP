Kodi Playback Resumer
=========================================================
script.service.playbackresumer

A simple addon to periodically update the resume point of the currently playing video automatically in the background, so that playback progress is not lost in the event of a Kodi crash.

Optionally, automatically resume playback automatically when Kodi is restarted after a crash, or trigger playback of a random video.

Main Kodi forum thread here:
https://forum.kodi.tv/showthread.php?tid=183084

(Original code by bradvido88 recovered from the Kodi forum, and from May 2019 updated & maintained in this repo by bossanova808).

