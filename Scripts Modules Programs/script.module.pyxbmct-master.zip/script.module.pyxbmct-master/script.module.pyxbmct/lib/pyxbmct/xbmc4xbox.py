import platform
def isXBMC4XBOX():
    # type: () -> bool
    return platform.system() == "XBMC4Xbox"