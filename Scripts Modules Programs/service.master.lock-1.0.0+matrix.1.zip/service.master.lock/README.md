# Master Lock Service
This basic Kodi services enables the Master Lock (is Kodi has one) whenever the screensaver kicks in.
