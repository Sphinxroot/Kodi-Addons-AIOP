#!/usr/bin/python
# -*- coding: utf-8 -*-

#######################################
#                                     #
# script.module.t0mus.common for xbmc #
# author: t0mus                       #
#                                     #
#######################################

"""Url extractor for putlocker host."""

import re


def extract_urls(soup):
    """Return list of urls."""

    urls = []
    try:
        pattern = '^http://(www.)*putlocker.com/embed/'
        for frame in soup.findAll('iframe',
                                  attrs={'src': re.compile(pattern)}):
            embed_url = frame['src']
            urls.append(None)
    except AttributeError:
        pass
    return urls


