#!/usr/bin/python
# -*- coding: utf-8 -*-

#######################################
#                                     #
# script.module.t0mus.common for xbmc #
# author: t0mus                       #
#                                     #
#######################################

"""Strings for script.module.t0mus.common."""

import os
import sys
import xbmc
import xbmcaddon

__addon__ = 'script.module.t0mus.common'
__settings__ = xbmcaddon.Addon(id=__addon__)

__string_dir__ = \
    xbmc.translatePath(os.path.join(__settings__.getAddonInfo('path'),
                       'resources'))
sys.path.append(__string_dir__)

__strings__ = __settings__.getLocalizedString

__categories_string__ = __strings__(30000)
__search_string__ = __strings__(30001)
__nextpage_string__ = __strings__(30002)
__movietitle_string__ = __strings__(30003)
__loadingmovies_string__ = __strings__(30004)
__loadingcategories_string__ = __strings__(30005)
__networkerror_string__ = __strings__(30006)
__unsupported_hosting_string__ = __strings__(30007)

