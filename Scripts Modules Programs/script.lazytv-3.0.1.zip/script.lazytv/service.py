from resources import main_service

if __name__ == "__main__":
    main_service.run()
    main_service.Main()
