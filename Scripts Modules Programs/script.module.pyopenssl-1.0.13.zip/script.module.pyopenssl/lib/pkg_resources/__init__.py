# This is a stub provided for ndg __init__.py
def declare_namespace(_):
    pass

def resource_filename(a, b):
    raise NotImplementedError