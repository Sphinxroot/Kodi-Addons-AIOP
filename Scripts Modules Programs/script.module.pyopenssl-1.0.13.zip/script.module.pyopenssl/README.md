kodi pyOpenSSL
============

pyOpenSSL library module packed for Kodi
Original pyOpenSSL package and dependencies were sourced from 

https://pypi.python.org/pypi/pyOpenSSL/0.13
https://pypi.python.org/pypi/ndg-httpsclient/0.3.3
https://pypi.python.org/pypi/pyasn1/0.1.7

It's currently pegged at 0.13 as 0.14 requires very different dependencies and at this stage 0.13 provides everything I need.
THe same pattern of including binary modules could likely be used to build a package for 0.15 as well.