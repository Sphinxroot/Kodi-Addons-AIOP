import acsync.rpc

import sys
import os

import xbmc
import xbmcaddon
import time

def main():
    rpc = acsync.rpc.RPC(xbmc)

    addon_id = os.path.basename(os.path.dirname(__file__))

    rpc.set_addon_state(addon_id, False)
    rpc.set_addon_state(addon_id, True)
    xbmc.executebuiltin("RunAddon)('%s')" % addon_id)

if __name__ == '__main__':
    main()
