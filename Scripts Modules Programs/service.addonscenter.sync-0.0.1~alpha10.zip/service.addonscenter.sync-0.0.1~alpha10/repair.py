import acsync.rpc

import os
import sys

import xbmc
import xbmcaddon


def main():
    xbmc.log('Run Repair Module')
    rpc = acsync.rpc.RPC(xbmc)

    addon_id = os.path.basename(os.path.dirname(__file__))
    userdata_path = xbmc.translatePath("special://profile")
    token_path = os.path.join(
        userdata_path, "addon_data", addon_id, "device.key")

    try:
        os.remove(token_path)
    except OSError as e:
        if os.path.isfile(token_path):
            xbmc.log('Device key could not be removed: %s' %
                     token_path)
            raise e

    xbmc.log('Re-enabled addon')
    rpc.set_addon_state(addon_id, False)
    rpc.set_addon_state(addon_id, True)
    xbmc.executebuiltin("RunAddon)('%s')" % addon_id)


if __name__ == '__main__':
    main()
