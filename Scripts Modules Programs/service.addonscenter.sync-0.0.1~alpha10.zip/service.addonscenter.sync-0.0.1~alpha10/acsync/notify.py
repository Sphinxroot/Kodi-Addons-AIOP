import urllib2


class Notify(object):

    def __init__(self, addon, xbmc, xbmcgui):
        self.addon = addon
        self.xbmc = xbmc
        self.xbmcgui = xbmcgui

    def toast(self, title, line1):
        time = 20000
        self.xbmc.executebuiltin(
            'Notification(%s, %s, %d)' % (title, line1, time))

    def yesno_modal(self, *args, **kwargs):
        self.xbmcgui.Dialog().yesno(*args, **kwargs)

    def ok_modal(self, *args, **kwargs):
        self.xbmcgui.Dialog().ok(*args, **kwargs)
