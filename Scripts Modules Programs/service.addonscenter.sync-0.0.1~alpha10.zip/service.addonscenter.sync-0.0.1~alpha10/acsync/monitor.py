
import xbmc


class Monitor(xbmc.Monitor):
    def __init__(self, state):
        self.state = state

    def onSettingsChanged(self):
        xbmc.Monitor.onSettingsChanged(self)
        self.state.load()
