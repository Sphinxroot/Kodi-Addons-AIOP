'''
    Sources Importer
    Copyright (C) 2015 Patrick Dijkkamp

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urllib2, re, os.path, sys, socket, shutil
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

addon = xbmcaddon.Addon(id= 'plugin.program.sourcesimporter')
addon_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()

urlopen = urllib2.urlopen
Request = urllib2.Request

sources = os.path.join(xbmc.translatePath('special://home'),'userdata', 'sources.xml')
sourcesbak = os.path.join(xbmc.translatePath('special://home'),'userdata', 'sources.bak')


def INDEX():
    addDir('Installeer sources in Videos','importsources',1, '')
    addDir('Installeer sources in Bestandsbeheer','importsources',2, '')
    addDir('Maak backup van sources.xml','backupsources','','')
    addDir('Herstel backup van sources.xml','restoresources','','')
    xbmcplugin.endOfDirectory(addon_handle)


def getSources(url):
    req = Request(url)
    response = urlopen(req, timeout=60)
    data = response.read()
    response.close()
    return data 


def IMPORTS(section):

    if not os.path.exists(sources): 
        dialog.ok('Geen sources.xml','Geen sources.xml gevonden','Voeg eerst een bron toe','om het bestand aan te maken')
        return
        
    if not os.path.exists(sourcesbak):
        ret = dialog.yesno('Geen backup','Geen backup gevonden','Wilt u deze eerst maken?')
        if ret:
            BACKUPS()

    if section == 1:
        strsection = '</video>'
        txtsection = 'Videos'
    elif section == 2:
        strsection = '</files>'
        txtsection = 'Bestandsbeheer'

    pblink = Keyboard('http://pastebin.com/raw/Wt5fWk17','Vul eventueel Pastebin url aan')
    if not pblink:
        return
    try:
        pbsource = getSources(pblink)
    except:
        dialog.ok('Error','Ophalen sources mislukt')
        return
        
    if not '<source>' in pbsource:
        if '&lt;source&gt;' in pbsource:
            try:
                pbsource2 = re.compile("<textarea.*?>([^<]+)</textarea>", re.DOTALL | re.IGNORECASE).findall(pbsource)
                pbsource = pbsource2[0]
                pbsource = pbsource.replace('&lt;','<')
                pbsource = pbsource.replace('&gt;','>')
                pbsource = pbsource.replace('&quot;','"')
            except:
                dialog.ok('Error','Geen bronnen gevonden')
                return
        else:
            dialog.ok('Error','Geen bronnen gevonden')
            return
    
    f  = open(sources, mode='r')
    str = f.read()
    f.close()
    
    if strsection in str:
        pbsource = pbsource + strsection
        str = str.replace(strsection,pbsource)
        f = open(sources, mode='w')
        f.write(str)
        f.close()
        ret = dialog.yesno('Herstart Kodi','Sources toegevoegd aan '+ txtsection,'U dient Kodi te herstarten','Wilt u dit nu doen?')
        if ret:
            xbmc.executebuiltin('XBMC.Quit')
        else:
            return
    return


def BACKUPS():
    if not os.path.exists(sources): 
        dialog.ok('Geen sources.xml','Geen sources.xml gevonden','Voeg eerst een bron toe','om het bestand aan te maken')
        return
    
    if os.path.exists(sourcesbak):
        ret = dialog.yesno('Oude backup gevonden','Oude backup gevonden','Deze wordt overschreven als u doorgaat','Wilt u doorgaan?')
        if ret:
            os.remove(sourcesbak)
        else:
            return
    
    shutil.copy(sources, sourcesbak)
    dialog.ok('Backup gemaakt','Backup van sources.xml is gemaakt')
    return


def RESTORES():
    if not os.path.exists(sources): 
        dialog.ok('Geen sources.xml','Geen sources.xml gevonden','Voeg eerst een bron toe','om het bestand aan te maken')
        return

    if not os.path.exists(sourcesbak): 
        dialog.ok('Geen backup gevonden','Maak eerst een backup')
        return

    if os.path.exists(sources):
        ret = dialog.yesno('Backup herstellen','Sources.xml herstellen','Deze wordt overschreven als u doorgaat','Wilt u doorgaan?')
        if ret:
            os.remove(sources)
        else:
            return
    
    shutil.copy(sourcesbak, sources)
    ret = dialog.yesno('Backup herstelt','Backup van sources.xml is terug gezet','Herstart Kodi om de sources opnieuw te laten','Wilt u dit nu doen?')
    if ret:
        xbmc.executebuiltin('XBMC.Quit')
    return


def addDir(name, mode, section, iconimage):
    u = (sys.argv[0] +
         "?mode=" + mode +
         "&section=" + str(section))
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=False)
    return ok

    
def Keyboard(default="", heading="", hidden=False):
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    else:
        return False


def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param
    
params = getParams()
mode = None
section = None

try:
    mode = params["mode"]
except:
    pass
try:
    section = int(params["section"])
except:
    pass

if mode is None: INDEX()
elif mode == 'importsources': IMPORTS(section)
elif mode == 'backupsources': BACKUPS()
elif mode == 'restoresources' : RESTORES()

xbmcplugin.endOfDirectory(addon_handle)

