script.module.tmdbsimple
======================

Python TMDB library packed for Kodi.

See https://github.com/celiao/tmdbsimple
